\<input filename casuing crash\> \<Defect Line Number\> 

handleid:000000,sig:11,src:000000,op:flip1,pos:310 73

handleid:000001,sig:11,src:000000,op:flip1,pos:593 73

id:000002,sig:11,src:000000,op:flip1,pos:892 73

id:000003,sig:11,src:000000,op:flip1,pos:1497 73

id:000004,sig:11,src:000000,op:flip1,pos:12085 73

id:000005,sig:11,src:000000,op:flip1,pos:59717 73

id:000006,sig:11,src:000000,op:flip1,pos:69148 73

id:000007,sig:11,src:000000,op:flip2,pos:272 73

id:000008,sig:11,src:000000,op:flip2,pos:48825 73

id:000009,sig:11,src:000000,op:flip4,pos:248 73

id:000010,sig:11,src:000000,op:arith8,pos:144,val:-34 73

id:000011,sig:11,src:000000,op:arith8,pos:261,val:-34 73